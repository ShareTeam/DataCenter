/**
 * Connection package for <a href="http://github.com/alphazero/jredis">JRedis</a> library.
 * @deprecated since 1.7. Will be removed in subsequent version.
 */
package org.springframework.data.redis.connection.jredis;

