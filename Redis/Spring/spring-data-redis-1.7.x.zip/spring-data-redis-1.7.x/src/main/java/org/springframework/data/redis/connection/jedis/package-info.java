/**
 * Connection package for <a href="http://github.com/xetorthio/jedis">Jedis</a> library.
 */
package org.springframework.data.redis.connection.jedis;

