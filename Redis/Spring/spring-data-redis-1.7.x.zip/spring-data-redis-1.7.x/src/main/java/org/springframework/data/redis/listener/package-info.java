/**
 * Base package for Redis message listener / pubsub container facility 
 */
package org.springframework.data.redis.listener;

